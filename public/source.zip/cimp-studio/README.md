# CIMP Partners Studio — Vercel edition

Next.js app for the Sunway CIMP booth display. The intro, transitions, light/dark themes, messages, video frames, photo collages, individual image framing and remote admin controls are retained.

## Deploy on Vercel

1. Replace the old repository source with this folder's contents. Keep your repository's `.git` folder. Remove the old `worker`, `db`, `drizzle`, `.openai` folders and old `vite.config.ts`, `drizzle.config.ts`, `cloudflare-env.d.ts` files. Do not combine the old Cloudflare package.json/lockfile with this version.
2. Commit and push to GitHub. In Vercel select **Next.js**, Node **22.x**, and the repository root directory. Clear any old build/output directory overrides. `vercel.json` provides the install/build commands.
3. In Vercel Storage, create/connect a **private Vercel Blob** store. Enable the read/write-token environment variable so `BLOB_READ_WRITE_TOKEN` is available.
4. Create/connect **Upstash Redis** through Vercel Marketplace. Set `UPSTASH_REDIS_REST_URL` and `UPSTASH_REDIS_REST_TOKEN` (the `KV_REST_API_URL` / `KV_REST_API_TOKEN` aliases also work).
5. Set **ADMIN_PASSWORD** to a unique password of at least 16 characters. Do not put secrets in Git or use a `NEXT_PUBLIC_` prefix.
6. Redeploy after adding the environment variables. Open `/admin`, sign in, then use **Open TV display**. Sign in once on the TV browser too; sessions last seven days.

The four required environment variables are listed in `.env.example`. Preview branches use separate playlist keys by default. Use separate storage connections for complete preview/production isolation. Optional `STUDIO_NAMESPACE` selects a shared or custom playlist key.

## Local development

Use Node 22.x. Copy `.env.example` to `.env.local` and fill in the same storage credentials and a local password.

```sh
npx pnpm@11.25.0 install --frozen-lockfile
npx pnpm@11.25.0 dev
```

```sh
npx pnpm@11.25.0 test
npx pnpm@11.25.0 build
node tests/http-smoke.mjs
```

`http-smoke.mjs` runs a production server with a local Redis REST test double; it does not connect to live storage. Live Blob uploads and signed CDN playback require the actual Vercel store and are not covered by that test.

## What changed for Vercel

- Standard Next.js build/start commands replace Vinext, Vite and Cloudflare Workers.
- Private Vercel Blob client uploads send media directly to storage with multipart retry/progress, up to 1 GB. Video playback redirects to a one-hour, file-specific signed CDN URL; the CDN handles seeking/range requests without proxying video through a function.
- Redis stores settings durably. An atomic compare-and-save rejects stale admin edits with a conflict message. The TV continues polling every three seconds.
- Password login protects the admin, TV and state/media APIs. HttpOnly signed cookies expire after seven days; changing the password invalidates existing sessions. Login attempts are rate limited in Redis.
- The lockfile matches the package configuration. `pnpm-workspace.yaml` explicitly permits Sharp and Tailwind's native build step. The obsolete esbuild/workerd dependencies have been removed. Do not run a blanket `approve-builds`.
- No filesystem writes are used for production state or media.

## Moving existing content

This source package contains the sample photo collection and video, not the old hosted application's private R2 uploads or saved playlist. Existing uploaded files do not move automatically between providers. Re-upload your photos/videos in the new admin and recreate your saved messages/settings before replacing the booth's display URL. Existing external HTTPS media links can be reused. The original ChatGPT-hosted site is unchanged.

## Source download

Run `python3 scripts/export-source.py` after editing to regenerate `public/source.zip`, which is downloadable from the admin's **Source code** button. The exporter excludes credentials, `.env.local`, Git, dependencies, cloud data and build outputs. It includes only `.env.example` as an environment template.

## Branding assets

- Sunway College official CIMP guide: https://sunwaycollege.edu.my/sites/default/files/inline-images/pdfs/cimp-guide-2025.pdf
- Sunway logo: https://sunwaycollege.edu.my/themes/contrib/osb5/sunway_college_logo.png
- Public-domain Canadian maple-leaf geometry: https://commons.wikimedia.org/wiki/File:Flag_of_Canada_(leaf).svg

The CIMP lettering and maple leaf are a presentation treatment, not a claim of an official standalone programme logo. Browsers may require a user gesture for audible autoplay; the TV supports M to enable audio and F for fullscreen.
